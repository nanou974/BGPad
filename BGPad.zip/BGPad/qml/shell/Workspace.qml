import QtQuick

Item {

    ListModel {
        id: tileModel

        ListElement {
            title: "Terminal"
            enabled: true
        }

        ListElement {
            title: "Bientôt"
            enabled: false
        }
    }

    Grid {
        anchors.centerIn: parent

        columns: 4
        spacing: 24

        Repeater {
            model: tileModel

            delegate: BGTile {
                text: title
                enabled: enabled

                onClicked: {
                    if (title === "Terminal")
                        backend.openTerminal()
                }
            }
        }
    }
}
