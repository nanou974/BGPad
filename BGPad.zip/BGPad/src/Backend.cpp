#include "Backend.h"

#include <QProcess>
#include <QWindow>

Backend::Backend(QObject *parent)
    : QObject(parent)
{
}

void Backend::setMainWindow(QWindow *window)
{
    m_mainWindow = window;
}

void Backend::openTerminal()
{
    if (m_mainWindow)
        m_mainWindow->showMinimized();

    QProcess::startDetached("xfce4-terminal");
}
