#include "ApplicationController.h"

ApplicationController::ApplicationController(QObject *parent)
    : QObject(parent)
{
    m_model.addApplication({
        "terminal",
        "Terminal",
        "",
        "xfce4-terminal",
        true
    });

    m_model.addApplication({
        "comingsoon",
        "Bientôt",
        "",
        "",
        false
    });
}

ApplicationModel *ApplicationController::model()
{
    return &m_model;
}
